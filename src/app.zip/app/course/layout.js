export const metadata = {
  title: "course",
  description: "Ai Powerd job Preparation Platform",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
