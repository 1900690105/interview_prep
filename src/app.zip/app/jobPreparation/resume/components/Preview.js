import Resume from "../../components/resume-templete/components/Resume";

export default function ResumePreview({ data }) {
  return (
    <>
      <Resume />
    </>
  );
}
