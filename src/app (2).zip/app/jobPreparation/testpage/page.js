import React from "react";
import Form from "../components/formtest";

const page = () => {
  return (
    <div>
      <Form />
    </div>
  );
};

export default page;
