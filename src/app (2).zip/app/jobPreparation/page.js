"use client";
import React, { useState } from "react";
import Instructions from "./components/Instruction";

const JobPreparation = () => {
  return (
    <>
      <Instructions />
    </>
  );
};

export default JobPreparation;
