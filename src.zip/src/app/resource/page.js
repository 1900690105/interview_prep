import React from "react";

function resource() {
  return (
    <>
      <div>
        <p>resource page</p>
      </div>
    </>
  );
}

export default resource;
