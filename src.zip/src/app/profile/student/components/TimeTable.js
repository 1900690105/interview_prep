import React from "react";

const StudentTimeTable = () => {
  return (
    <>
      <div>StudentTimeTable</div>
    </>
  );
};

export default StudentTimeTable;
