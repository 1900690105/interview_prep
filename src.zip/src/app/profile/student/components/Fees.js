import React from "react";

const StudentFees = () => {
  return (
    <>
      <div>StudentFees</div>
    </>
  );
};

export default StudentFees;
