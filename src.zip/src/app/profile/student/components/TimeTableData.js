export const Datatimetable = {
  Monday: [
    {
      time: "10:30 AM - 11:30 AM",
      subject: "BDA",
      teacher: "RST",
    },
    {
      time: "11:30 AM - 12:30 PM",
      subject: "DT",
      teacher: "RST",
    },
    {
      time: "12:30 PM - 01:30 PM",
      subject: "AI",
      teacher: "RST",
    },
    {
      time: "01:30 PM - 01:50 PM",
      subject: "Break",
    },
    {
      time: "01:50 PM - 02:50 PM",
      subject: "BI",
      teacher: "RDD",
    },
    {
      time: "02:50 PM - 03:50 PM",
      subject: "CC",
      teacher: "VRS",
    },
    {
      time: "03:50 PM - 04:00 PM",
      subject: "Break",
    },
    {
      time: "04:00 PM - 05:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
    {
      time: "05:00 PM - 06:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
  ],
  Tuesday: [
    {
      time: "10:30 AM - 11:30 AM",
      subject: "BDA",
      teacher: "RST",
    },
    {
      time: "11:30 AM - 12:30 PM",
      subject: "DT",
      teacher: "RST",
    },
    {
      time: "12:30 PM - 01:30 PM",
      subject: "AI",
      teacher: "RST",
    },
    {
      time: "01:30 PM - 01:50 PM",
      subject: "Break",
    },
    {
      time: "01:50 PM - 02:50 PM",
      subject: "BI",
      teacher: "RDD",
    },
    {
      time: "02:50 PM - 03:50 PM",
      subject: "CC",
      teacher: "VRS",
    },
    {
      time: "03:50 PM - 04:00 PM",
      subject: "Break",
    },
    {
      time: "04:00 PM - 05:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
    {
      time: "05:00 PM - 06:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
  ],
  Wednesday: [
    {
      time: "10:30 AM - 11:30 AM",
      subject: "BDA",
      teacher: "RST",
    },
    {
      time: "11:30 AM - 12:30 PM",
      subject: "DT",
      teacher: "RST",
    },
    {
      time: "12:30 PM - 01:30 PM",
      subject: "AI",
      teacher: "RST",
    },
    {
      time: "01:30 PM - 01:50 PM",
      subject: "Break",
    },
    {
      time: "01:50 PM - 02:50 PM",
      subject: "BI",
      teacher: "RDD",
    },
    {
      time: "02:50 PM - 03:50 PM",
      subject: "CC",
      teacher: "VRS",
    },
    {
      time: "03:50 PM - 04:00 PM",
      subject: "Break",
    },
    {
      time: "04:00 PM - 05:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
    {
      time: "05:00 PM - 06:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
  ],
  Thursday: [
    {
      time: "10:30 AM - 11:30 AM",
      subject: "BDA",
      teacher: "RST",
    },
    {
      time: "11:30 AM - 12:30 PM",
      subject: "DT",
      teacher: "RST",
    },
    {
      time: "12:30 PM - 01:30 PM",
      subject: "AI",
      teacher: "RST",
    },
    {
      time: "01:30 PM - 01:50 PM",
      subject: "Break",
    },
    {
      time: "01:50 PM - 02:50 PM",
      subject: "BI",
      teacher: "RDD",
    },
    {
      time: "02:50 PM - 03:50 PM",
      subject: "CC",
      teacher: "VRS",
    },
    {
      time: "03:50 PM - 04:00 PM",
      subject: "Break",
    },
    {
      time: "04:00 PM - 05:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
    {
      time: "05:00 PM - 06:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
  ],
  Friday: [
    {
      time: "10:30 AM - 11:30 AM",
      subject: "BDA",
      teacher: "RST",
    },
    {
      time: "11:30 AM - 12:30 PM",
      subject: "DT",
      teacher: "RST",
    },
    {
      time: "12:30 PM - 01:30 PM",
      subject: "AI",
      teacher: "RST",
    },
    {
      time: "01:30 PM - 01:50 PM",
      subject: "Break",
    },
    {
      time: "01:50 PM - 02:50 PM",
      subject: "BI",
      teacher: "RDD",
    },
    {
      time: "02:50 PM - 03:50 PM",
      subject: "CC",
      teacher: "VRS",
    },
    {
      time: "03:50 PM - 04:00 PM",
      subject: "Break",
    },
    {
      time: "04:00 PM - 05:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
    {
      time: "05:00 PM - 06:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
  ],
  Saturday: [
    {
      time: "10:30 AM - 11:30 AM",
      subject: "BDA",
      teacher: "RST",
    },
    {
      time: "11:30 AM - 12:30 PM",
      subject: "DT",
      teacher: "RST",
    },
    {
      time: "12:30 PM - 01:30 PM",
      subject: "AI",
      teacher: "RST",
    },
    {
      time: "01:30 PM - 01:50 PM",
      subject: "Break",
    },
    {
      time: "01:50 PM - 02:50 PM",
      subject: "BI",
      teacher: "RDD",
    },
    {
      time: "02:50 PM - 03:50 PM",
      subject: "CC",
      teacher: "VRS",
    },
    {
      time: "03:50 PM - 04:00 PM",
      subject: "Break",
    },
    {
      time: "04:00 PM - 05:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
    {
      time: "05:00 PM - 06:00 PM",
      subject: "Project-I",
      teacher: "Respected faculty",
    },
  ],
};
