import React from "react";

const TeacherDashaboard = () => {
  return <div>hello</div>;
};

export default TeacherDashaboard;
