import React from "react";

function Users() {
  return <h1 className="text-3xl font-bold">Users</h1>;
}

export default Users;
